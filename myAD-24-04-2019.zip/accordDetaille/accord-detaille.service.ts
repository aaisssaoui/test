import { Injectable } from '@angular/core';
import { RequesterService } from '../shared/services/requester/requester.service';
import { Observable } from 'rxjs';
import { ValidationErrors } from '@angular/forms';
import { map } from 'rxjs/operators';
import { AuthService } from '../services/auth/auth.service';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AccordDetailleService {
  ACCORD_API_VALID: string;
  public headers =  new HttpHeaders({ 'Content-Type': 'application/json' });
  public ACCORD_API_INIT_RATIF_FROM_DOSSIER: string;
  public ACCORD_API_LIST_PRODUITS_COMM: string;
  public ACCORD_API_LIST_ACC: string;

  constructor(  private http: RequesterService,
                private authService: AuthService) {
    this.ACCORD_API_VALID = `${authService.API_URL}/accord/validate`;
    this.ACCORD_API_INIT_RATIF_FROM_DOSSIER = `${authService.API_URL}/accord/ratifier`;
    this.ACCORD_API_LIST_PRODUITS_COMM = `${authService.API_URL}/accord/listeProduits`;
    this.ACCORD_API_LIST_ACC = `${authService.API_URL}/accord/loadAllList`;
  }

  AsyncValidatorAccord(data): Observable<ValidationErrors | null> {
    const api = { method: 'POST', url: this.ACCORD_API_VALID,  headers: this.headers};
    return this.http.request(api, { body: data }, true).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  getDossierARatifier(dossierID) {
    const api = {
      method: 'GET',
      url: this.ACCORD_API_INIT_RATIF_FROM_DOSSIER + '/' + dossierID
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
      }))
    );
  }
  getProduitCommerciaux(): Observable<any> {
    const api = {
      method: 'GET',
      url: this.ACCORD_API_LIST_PRODUITS_COMM
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
      }))
    );
  }
  getAllList(apporteurDossierID): Observable<any> {
    const api = {
      method: 'GET',
      url: this.ACCORD_API_LIST_ACC + '/' + apporteurDossierID
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
      }))
    );
  }
}
