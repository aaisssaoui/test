import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutresMajorationsComponent } from './autres-majorations.component';

describe('AutresMajorationsComponent', () => {
  let component: AutresMajorationsComponent;
  let fixture: ComponentFixture<AutresMajorationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutresMajorationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutresMajorationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
