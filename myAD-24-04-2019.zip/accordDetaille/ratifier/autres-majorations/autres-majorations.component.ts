import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ModelOption } from 'src/app/models/option-model';
import { FormGroup, FormArray } from '@angular/forms';

@Component({
  selector: 'app-autres-majorations',
  templateUrl: './autres-majorations.component.html',
  styleUrls: ['./autres-majorations.component.scss']
})
export class AutresMajorationsComponent implements OnInit {
 /*  tauxMajorationList: ModelOption[] = [
    new ModelOption('% du loyer', '% du loyer'),
    new ModelOption('€', 'Euro')]; */

  @Input()
  listTauxMaj;

  @Input()
  listAutresMaj;

  @Input()
  formgroup;

  @Input()
  parentMajorForm: FormGroup;

  @Input()
  index;

  @Output()
  buttAdd = new EventEmitter<any>();

  @Input()
  parentautresMajForm: FormGroup;

  constructor() { }

  ngOnInit() {
  }
  onClickAdd() {
    this.buttAdd.emit();
  }
  removeAutresMajForm(idx: number) {
    (<FormArray>this.parentautresMajForm.get('listAutresMaj')).removeAt(idx);
  }
}
