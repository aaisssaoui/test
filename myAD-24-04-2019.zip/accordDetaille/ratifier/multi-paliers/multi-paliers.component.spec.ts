import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiPaliersComponent } from './multi-paliers.component';

describe('MultiPaliersComponent', () => {
  let component: MultiPaliersComponent;
  let fixture: ComponentFixture<MultiPaliersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiPaliersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiPaliersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
