import { Component, OnInit, OnDestroy, AfterViewInit, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors,
  MaxLengthValidator,
  FormArray,
  FormControl
} from '@angular/forms';
import { ModelOption } from 'src/app/models/option-model';
import { MatDialog, MatSnackBarConfig, MatSnackBar } from '@angular/material';
import { RachatDetailsComponent } from './rachat-details/rachat-details.component';
import Global from '../../models/global-functions';
import { ActivatedRoute } from '@angular/router';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import { AdMethodeCalcul } from '../../models/enums/ad-methode-calcul.enum';
import { AuthService } from '../../services/auth/auth.service';
import { Observable } from 'rxjs';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { map, debounceTime, first } from 'rxjs/operators';
import { AccordDetailleService } from '../accord-detaille.service';
import { AccordDetaille, RatificationInfo, DossierInfo, DossierInfo2, ProduitCommercialInfo, ListesForAccord, FrfListPrestations, PeriodiciteCode, CatalogueBaremeStandardInfo, CatalogueBaremeAvanceInfo, ModeReglementCode, AutreMajorationInfo, ModeAmortissementCode, TermeCode, CatalogueGarantieInfo, MotifDerogationCode, CriteresGestionRatificationAvanceeInfo, InfoMajDDFInfo, VendeurInfo, PrestationInfo, CriteresRechercheRachatVo, Rachat, MontantInfo, CalageDDFInfo } from '../../models/ddf';
import { DdfService } from '../../services/ddf/ddf.service';
import { DossierHeader, DossierHeaderBuilder } from '../../dossier/dossier-header/dossier-header.component';
import { ContratService } from '../../services/contrat/contrat.service';
import { RatificationService } from '../../services/ddf/ratification.service';
import { MultiPaliersComponent } from './multi-paliers/multi-paliers.component';
import { CustomSearch } from '../../shared/components/phase-data-list/CustomSearch';
import { CritereRechercheInfo } from '../../models/critere-recherche-info';
import { RachatService } from '../../services/rachat/rachat.service';


@Component({
  selector: 'app-ratifier',
  templateUrl: './ratifier.component.html',
  styleUrls: ['./ratifier.component.scss']
})
export class RatifierComponent implements OnInit, OnDestroy, AfterViewInit {
  waitingTime = 1000;
  lastCall = new Date().getTime();
  lastRecall = null;
  isAbouttoValidate = false;
  validate$;
  public validator$;
  validationError: any = null;
  /*Déclaration des labels*/
   refApporteur = 'Référence apporteur';
   prodCommercial = 'Produit commercial';
   periodicite = 'Périodicité';
   duree = 'Durée';
   authRestante = 'Autorisation restante';
   derogation = '';
   methodeCalcul = 'Méthode de calcul';
   tauxTvaLabel = 'Taux de T.V.A';
   loyerFinancier = 'Loyer financier';
   montantLabel = 'Montant';
   tauxTEGM = 'Taux TEGM';
   fraisMontageLabel = 'Frais de montage';
   clauseIndexationLabel = 'Clause indexation';
   commissionApporLabel = 'Commission apporteur';
   bareme = 'Barème';
   baremeElargi = 'Barème élargi';
   baremeOrigineLabel = 'Code barème origine';
   valResiduelle = 'Valeur résiduelle';
   pourcentageMNT = '% du montant';
   premierLoyMaj = 'Premier loyer majoré';
   nbrJours = 'Nombre de jours';
   modeReglement = 'Mode de règlement';
   apporteur = 'Apporteur';
   nom = 'Nom';
   prenom = 'Prénom';
   agence = 'Agence';
   mail = 'Mail';
   telephone = 'Téléphone';
   fax = 'Fax';
   message = 'Message';
   comSatusLabel = 'Commentaire';
   comInterneLabel = 'Commentaire interne';
   dateStatutLabel = 'Date';
   gestStatLabel = 'Gestionnaire';
   montantGlobalIntegre = 'Le montant global intègre';
   avantEcheance = 'Avant échéance de';
   garantie = 'Sélectionner une garantie';
  /*fin déclaration*/
  globalForm: FormGroup;
  simulationFormGroup: FormGroup;
  ComplPFFormGroup: FormGroup;
  calageFormGroup: FormGroup;
  autresMajFormGroup: FormGroup;
  reglementFormGroup: FormGroup;
  identVendeurFormGroup: FormGroup;
  /* identVendeur2FormGroup: FormGroup; */
  statutFormGroup: FormGroup;
  rachatFormGroup: FormGroup;

  listAutresMaj: FormArray;
  assuranceFormGroup: FormGroup;
  listAssdommages: FormArray;
  listAssurances: FormArray;
  listAsspertefinancieres: FormArray;

  assMaintFormGroup: FormGroup;

  materielsFormGroup: FormGroup;
  listMateriels: FormArray;

  observationForm: FormGroup;
  garantiesFormGroup: FormGroup;
  listGaranties: FormArray;

  public translate: TranslateService;

  options: ModelOption[] = [
    new ModelOption('Option 1', 'opt1'),
    new ModelOption('Option 2', 'opt2'),
    new ModelOption('Option 3', 'opt3') ];

  tauxMajorationList: ModelOption[] = [
    new ModelOption('% du loyer', '% du loyer'),
    new ModelOption('€', 'Euro')];


  typePercentMontant: ModelOption[] = [
      new ModelOption('% du montant', 'montantP'),
      new ModelOption('% du loyer', 'loyerP'),
      new ModelOption('€', 'euro'),
      new ModelOption('Montant total des prestations', 'montantT'),
    ];
   methodeCalculList: ModelOption[] = [
    new ModelOption('Loyer financier', 'LOY'),
    new ModelOption('Montant', 'MON')
  ];
  listTauxGlobal: ModelOption[] = [
    new ModelOption('Taux global', 'TG'),
    new ModelOption('Taux de refinancement', 'TR')
  ];
  listTEGM: ModelOption[] = [
    new ModelOption('TEGM', 'TEGM'),
    new ModelOption('TEGT', 'TEGT'),
    new ModelOption('TEGS', 'TEGS'),
    new ModelOption('TEGA', 'TEGA')
  ];

  test;

  valPreset;

  formatNumber = new AmountFormatter();
  /* pre rempli */
  montantAuthrestante;
  isModeDerogation = true;
  MethodeEnum = AdMethodeCalcul;

  valRachat: number;
  daterachat: Date;
  loyerFinReadOnly = false;
  montantReadOnly = false;
  tauxReadOnly = false;
  authError$;
  modeAD;
  modeForcer = false;
  test2: any;
  commissionAppor; /* pré-remplie */
  clauseIndexation;
  homeBackFn: () => any;

  baremeOrigine = '--';
  comSatus =   '--';
  comInterne = '--';
  dateStatut = '--';
  gestionStatut = '--';
  showTauxMarge = false;
  tauxGlobal = 0;

  selectedTaux: ModelOption;

  dossierHeader: DossierHeader;
 /* options: any [] = ['% du montant', '% du loyer', '€', 'Montant total des prestations']; */

/*   libelle: string;
  value: string;
  data: any; */

  public ratificationInfo: RatificationInfo;

  dossier: DossierInfo;
  accordDetInfo: AccordDetaille;

  ddf$;
  numeroFL: number;
  chronoRatif: number;
  public buildAccordFromRatif$;
  public buildAccordFromDossier$;
  public showSpinner = false;
  isRatifError = false;
  ddfData: DossierInfo;
  public listProduit$;
 // listProduitsCom: ModelOption[] = [];
  listProduitsCom: ProduitCommercialInfo[]  = [];
  listPeriodicite: PeriodiciteCode []  = [];
  listBareme: CatalogueBaremeStandardInfo [] = [];
  listBaremeElargi: CatalogueBaremeAvanceInfo[] = [];
  listModeReglement: ModeReglementCode[] = [];
  listAutresMajoration: AutreMajorationInfo[] = [];
  listModeAmort: ModeAmortissementCode[] = [];
  listTerme: TermeCode[] = [];
  listGar: CatalogueGarantieInfo[] = [];
  listOrigineDerog: MotifDerogationCode[] = [];

  listAssMaint: ModelOption[] = [];

  produitComIndex;
  periodiciteIndex;
  modeRegIndex;
  motifDerInex;
  prestas: PrestationInfo [] = [];
  autresMajorations: AutreMajorationInfo [] = [];

  montant = 10000;
  public listPestations$;
  listPrestations: FrfListPrestations;

  defaultAssValue: any;

  criterGestRatifAvance: CriteresGestionRatificationAvanceeInfo  = {};
  gestionnaire: InfoMajDDFInfo;
  apporteurDossierID: number;
  isInterne: boolean;
  public rachats$;
  fraisMontage: MontantInfo;
  isCalage = false;
  calage: CalageDDFInfo;

  constructor(private _formBuilder: FormBuilder,
              public dialog: MatDialog,
              private ts: TranslateService,
              private route: ActivatedRoute,
              private authService: AuthService,
              private accordService: AccordDetailleService,
              private ddfService: DdfService,
              private contratService: ContratService,
              private ratifservice: RatificationService,
              private rachatService: RachatService,
              private snackBar: MatSnackBar
              ) {
    this.ts.get('ACCORD_DETAILLE.SIMULATION.TITLE.TITRE').subscribe(_ => {
      this.refApporteur = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.REFERENCE_APPORTEUR');
      this.prodCommercial = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.PRODUIT_COMMERCIAL')+'*';
      this.periodicite = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.PERIODICITE')+'*';
      this.duree = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.DUREE');
      this.authRestante = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.AUTORISATION_RESTANTE');
      /* this.derogation = this.ts.instant(''); */
      this.methodeCalcul = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.METHODE_CALCUL');
      this.tauxTvaLabel = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.TAUX_TVA')+'*';
      this.loyerFinancier = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.LOYER_FINANCIER');
      this.montantLabel = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.MONTANT');
      this.tauxTEGM = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.TAUX_TEGM')+'*';
      this.fraisMontageLabel = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.FRAIS_MONTAGE');
      this.clauseIndexationLabel = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.CLAUSE_INDEXATION');
      this.commissionApporLabel = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.COMMISSION_APPORTEUR');
      this.bareme = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.BAREME');
      this.baremeElargi = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.BAREME_ELARGI');
      this.baremeOrigineLabel = this.ts.instant('ACCORD_DETAILLE.SIMULATION.FIELDS.BAREME_ORIGINE');
      this.valResiduelle = this.ts.instant('ACCORD_DETAILLE.COMPLEMENT_PLAN_FINANCIER.FIELDS.VALEUR_RESIDUELLE');
      this.pourcentageMNT = this.ts.instant('ACCORD_DETAILLE.COMPLEMENT_PLAN_FINANCIER.FIELDS.POURCENTAGE_MONTANT');
      this.premierLoyMaj = this.ts.instant('ACCORD_DETAILLE.COMPLEMENT_PLAN_FINANCIER.FIELDS.PREMIER_LOYER_MAJORE');
      this.nbrJours = this.ts.instant('ACCORD_DETAILLE.CALAGE.FIELDS.NBR_JOURS');
      this.modeReglement = this.ts.instant('ACCORD_DETAILLE.REGLEMENT.FIELDS.MODE')+'*';
      this.apporteur = this.ts.instant('ACCORD_DETAILLE.IDENTIFICATION_VENDEUR.FIELDS.APPORTEUR')+'*';
      this.nom = this.ts.instant('ACCORD_DETAILLE.IDENTIFICATION_VENDEUR.FIELDS.NOM');
      this.prenom = this.ts.instant('ACCORD_DETAILLE.IDENTIFICATION_VENDEUR.FIELDS.PRENOM');
      this.agence = this.ts.instant('ACCORD_DETAILLE.IDENTIFICATION_VENDEUR.FIELDS.AGENCE');
      this.mail = this.ts.instant('ACCORD_DETAILLE.IDENTIFICATION_VENDEUR.FIELDS.MAIL');
      this.telephone = this.ts.instant('ACCORD_DETAILLE.IDENTIFICATION_VENDEUR.FIELDS.TELEPHONE');
      this.fax = this.ts.instant('ACCORD_DETAILLE.IDENTIFICATION_VENDEUR.FIELDS.FAX');
      this.message = this.ts.instant('ACCORD_DETAILLE.OBSERVATIONS.FIELDS.MESSAGE');
      this.comSatusLabel = this.ts.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.FIELDS.COMMENTAIRE_STATUS');
      this.comInterneLabel = this.ts.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.FIELDS.COMMENTAIRE_INTERNE');
      this.dateStatutLabel = this.ts.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.FIELDS.DATE_STATUS');
      this.gestStatLabel = this.ts.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.FIELDS.GESTIONNAIRE_STATUT');
      this.montantGlobalIntegre = this.ts.instant('ACCORD_DETAILLE.RACHAT.FIELDS.MONTANT_GLOBAL_INTEGRE');
      this.avantEcheance = this.ts.instant('ACCORD_DETAILLE.RACHAT.FIELDS.AVANT_ECHEANCE');
      this.garantie = this.ts.instant('ACCORD_DETAILLE.GARANTIES_CONDITION.FIELDS.SELECTIONNER_GARANTIE');
    });
      this.route.params.subscribe(params => {
        console.log('params.mode = ' + params.mode);
        console.log('numeroFL =  ' + params.did);
        console.log('chronoRatif =  ' + params.chrono);
        this.numeroFL = params.did;
        this.chronoRatif = params.chrono;
        this.modeForcer = (params.mode === 'forcer' ? true : false);
        console.log('this.modeForcer = ' + this.modeForcer);
        this.authError$ = (params.mode === 'ratifier' ? '' : params.mode === 'forcer' ? ''
                            : this.authService.setSubscribeError({status: '404'}));
      }
    );
  }

  ngOnInit() {
    /* if ( this.numeroFL) {
      if (!this.chronoRatif) {
        this.initAccordFromDossier();
      } else {
        this.initAccordFromRatif();
      }
    } */
    this.isInterne = this.authService.isInterne();
    this.initAccordFromDossier();
  }
  ngAfterViewInit(): void {
    this.test = this.options[0].value;
  }
  ngOnDestroy() {
    this.authService.setSubscribeError(null);
    this.validate$.unsubscribe();
    Global.unsubscriber(this.ddf$);
     }
  buildAccordDetaille() {
    this.buildSimulationForm();
    this.buildPlanFinForm();
    this.bluidCalageForm();
    this.buildAutresMaj();
    this.buildReglement();
    this.buidIdentVendeur();
    this.buidStatut();
    this.buildRachat();
    this.buildAssurance();
    this.buildAssMaintenance();
    this.buildMateriels();
    this.buildObservation();
    this.buildGaranties();
    this.buildGlobalForm();
  }
  buildGlobalForm() {
    this.globalForm = this._formBuilder.group({
      simulationForm: this.simulationFormGroup,
      compPlanFinForm : this.ComplPFFormGroup,
      calageForm : this.calageFormGroup,
      autresMajorForm: this.listAutresMaj,
      modeReglementForm: this.reglementFormGroup,
      identVendeurForm: this.identVendeurFormGroup,
      statutForm: this.statutFormGroup,
      rachatForm: this.rachatFormGroup,
      assuranceForm :  this.listAssurances,
      assuranceDomForm : this.listAssdommages,
      assuranceFinForm  : this.listAsspertefinancieres,
      assuranceMaintForm : this.assMaintFormGroup,
      materialForm : this.listMateriels,
      observationForm : this.observationForm,
      garantiesForm : this.garantiesFormGroup
    });
  }
  buildObjectCritereRatif () {
    this.prestas = [];
    this.autresMajorations = [];
    this.fraisMontage = null;
    this.calage = null;

    this.criterGestRatifAvance.numFlashLease =  this.dossier.numeroFL ? this.dossier.numeroFL : null;
    this.criterGestRatifAvance.chrono = this.chronoRatif ? this.chronoRatif : null;
    this.gestionnaire = {
      statut : this.ratificationInfo.statutRatification ? this.ratificationInfo.statutRatification : null,
      gestionnaireStatut : this.ratificationInfo.statutRatification.gestionnaire ?
                            this.ratificationInfo.statutRatification.gestionnaire : null,
      numFlashLease : this.dossier.numeroFL
    };
    this.criterGestRatifAvance.gestionaire = this.gestionnaire ? this.gestionnaire : null;
    this.criterGestRatifAvance.typeOperation = this.ratificationInfo.typeOperation ? this.ratificationInfo.typeOperation : null;
    // temporaire : faire un test su les rachats !!
    this.criterGestRatifAvance.rachat = this.ratificationInfo.rachat ? this.ratificationInfo.rachat : null;

    this.criterGestRatifAvance.materielsFinancement = this.ratificationInfo.materielsFinancement ?
                                                          this.ratificationInfo.materielsFinancement : null;
    this.criterGestRatifAvance.fournisseurs = this.ratificationInfo.fournisseurs ? this.ratificationInfo.fournisseurs : null;


    // this.ratificationInfo.motifDerogation
    this.criterGestRatifAvance.motifDerogation = this.ratificationInfo.topDerogation ?
                                                  this.simulationFormGroup.get('afOrigineDero').value.code : null;
    this.criterGestRatifAvance.derogation = this.simulationFormGroup.get('arDerogation').value;

    this.criterGestRatifAvance.typeRatification = this.ratificationInfo.typeRatification ?
                                                  this.ratificationInfo.typeRatification : null;
    // this.criterGestRatifAvance.isDiffusion = ;
    this.criterGestRatifAvance.isMultiPalier = this.ratificationInfo.isMultiPalier ?
                                                this.ratificationInfo.isMultiPalier : null;

    this.fraisMontage = this.ratificationInfo.montantFraisDeMontage ?
                          this.ratificationInfo.montantFraisDeMontage : null;
    if (this.simulationFormGroup.get('arFaisMontage').touched) {
      this.fraisMontage.montant = this.simulationFormGroup.get('arFaisMontage').value;
      }
    this.criterGestRatifAvance.montantFraisDeMontage = this.fraisMontage;

    this.criterGestRatifAvance.fraisMontageForce = this.ratificationInfo.fraisDeMontageForce ?
                                                    this.ratificationInfo.fraisDeMontageForce : null;
    this.criterGestRatifAvance.prctFinancement = this.ratificationInfo.prctFinancement ?
                                                  this.ratificationInfo.prctFinancement : 0;
    // this.criterGestRatifAvance.garanties = ;
    console.log('calage : ' + this.calageFormGroup.get('arCalage').value);

    this.calage = this.ratificationInfo.calage ? this.ratificationInfo.calage : null;
    if (this.calageFormGroup.touched) {
      this.calage.nbJoursCalage = this.calageFormGroup.get('arCalage').value;
      this.calage.topCalage = this.calageFormGroup.get('arCalage').value;
    }
    this.criterGestRatifAvance.calage = this.calage;

   // this.calageFormGroup.get('arCalage')  arNbrJours

   this.criterGestRatifAvance.codeProduitFinancier = this.simulationFormGroup.get('arProduitCommercial')
                                                          .value.produitFinancier.code;
   this.criterGestRatifAvance.codeProduitCommercial =  this.simulationFormGroup.get('arProduitCommercial')
                                                            .value.code;
   this.criterGestRatifAvance.periodicite  = this.simulationFormGroup.get('arPeriodicite').value.code;
    // this.criterGestRatifAvance.periodicite  = null;
   this.criterGestRatifAvance.duree = this.simulationFormGroup.get('arDuree').value;
   this.criterGestRatifAvance.montant  = this.simulationFormGroup.get('arMontant').value;
   this.criterGestRatifAvance.codeTerme = this.ratificationInfo.planFinancement.terme ?
                                           this.ratificationInfo.planFinancement.terme.code : null;

   this.criterGestRatifAvance.loyerMajore =  this.ratificationInfo.planFinancement.loyerFinancierMajore ?
                                                this.ratificationInfo.planFinancement.loyerFinancierMajore : null;

   this.criterGestRatifAvance.methodeCalcul  = this.simulationFormGroup.get('arMethodeCalcul').value ?
                                               this.simulationFormGroup.get('arMethodeCalcul').value.code : null;
   this.criterGestRatifAvance.modeleContrat  = this.ratificationInfo.modeleContrat ?
                                                this.ratificationInfo.modeleContrat.code : null;
   this.criterGestRatifAvance.modeReglement  =  this.reglementFormGroup.get('modeReglement').value;
   this.criterGestRatifAvance.premierLoyer  = this.simulationFormGroup.get('arLoyerFinancier').value ?
                                                this.simulationFormGroup.get('arLoyerFinancier').value.code : null;
  // this.criterGestRatifAvance.modeSaisiePremierLoyer  =
   // this.criterGestRatifAvance.modeSaisieVR  =
   if (this.assuranceFormGroup.get('listAssurances').value) {
    this.assuranceFormGroup.get('listAssurances').value.map( item => {
      if (item.typeAssurance) {
      this.prestas.push(item.typeAssurance);
      }
      });
   }
   if (this.assuranceFormGroup.get('listAssdommages').value) {
    this.assuranceFormGroup.get('listAssdommages').value.map( item => {
      if (item.typeAssurance) {
        this.prestas.push(item.typeAssurance);
      }
      });
   }
   if (this.assuranceFormGroup.get('listAsspertefinancieres').value) {
    this.assuranceFormGroup.get('listAsspertefinancieres').value.map( item => {
      if (item.typeAssurance) {
      this.prestas.push(item.typeAssurance);
      }
      });
   }
   this.criterGestRatifAvance.prestations = this.prestas;
   this.criterGestRatifAvance.referenceApporteur  = this.simulationFormGroup.get('arReferenceApporteur').value ?
                                                          this.simulationFormGroup.get('arReferenceApporteur').value : null;
   this.criterGestRatifAvance.codeCampagne  = this.ratificationInfo.bareme ?
                                              this.ratificationInfo.bareme.libelleCampagne : null;
   this.criterGestRatifAvance.libelleCampagne  = this.ratificationInfo.bareme ?
                                                  this.ratificationInfo.bareme.libelleCampagne : null;
   // this.criterGestRatifAvance.clientAssujettiTaxePro  =
   // this.criterGestRatifAvance.modeSaisiMontant  =
   const vendeur: VendeurInfo = this.ratificationInfo.vendeur;

   if (this.identVendeurFormGroup.get('adApporteur').touched) {
    vendeur.agence.apporteur.libelle = this.identVendeurFormGroup.get('adApporteur').value;
   }
   if (this.identVendeurFormGroup.get('adNom').touched) {
    vendeur.nom = this.identVendeurFormGroup.get('adNom').value;
   }
   if (this.identVendeurFormGroup.get('adPrenom').touched) {
    vendeur.prenom = this.identVendeurFormGroup.get('adPrenom').value;
   }
   if (this.identVendeurFormGroup.get('adAgence').touched) {
    vendeur.agence.libelle = this.identVendeurFormGroup.get('adAgence').value;
   }
   if (this.identVendeurFormGroup.get('adMail').touched) {
    vendeur.mail = this.identVendeurFormGroup.get('adMail').value;
   }
   if (this.identVendeurFormGroup.get('adTelephone').touched) {
    vendeur.telephone = this.identVendeurFormGroup.get('adTelephone').value;
   }
   if (this.identVendeurFormGroup.get('adFax').touched) {
    vendeur.fax = this.identVendeurFormGroup.get('adFax').value;
   }
   this.criterGestRatifAvance.vendeur  = vendeur;
   // this.criterGestRatifAvance.commentaire =
   // this.criterGestRatifAvance.donneesDiffusion  =
   this.criterGestRatifAvance.rachatIds  = this.ratificationInfo.rachatIds ? this.ratificationInfo.rachatIds : null;
   this.criterGestRatifAvance.offreRachatLabel  = this.ratificationInfo.offreRachatLabel ? this.ratificationInfo.offreRachatLabel : null;

   if (this.autresMajFormGroup.get('listAutresMaj').value) {
    this.autresMajFormGroup.get('listAutresMaj').value.map( item => {
      if (item.typeAssurance) {
        this.autresMajorations.push(item.typeAssurance);
      }
      });
   }
   this.criterGestRatifAvance.autreMajorations = this.autresMajorations;

   this.criterGestRatifAvance.paliers  = this.ratificationInfo.planFinancement.paliers ?
                                              this.ratificationInfo.planFinancement.paliers : null;
   this.criterGestRatifAvance.taux  = this.simulationFormGroup.get('arTauxTEGM').value;
   this.criterGestRatifAvance.tauxRefinancement  = this.ratificationInfo.planFinancement.tauxRefinancement ?
                                                    this.ratificationInfo.planFinancement.tauxRefinancement : null;
   this.criterGestRatifAvance.tauxMarge  = this.ratificationInfo.planFinancement.tauxMarge ?
                                            this.ratificationInfo.planFinancement.tauxMarge : null;
   this.criterGestRatifAvance.periodiciteTaux  = this.ratificationInfo.planFinancement.periodiciteTaux ?
                                                  this.ratificationInfo.planFinancement.periodiciteTaux.code : null;
   this.criterGestRatifAvance.modeAmortissement  = this.ratificationInfo.planFinancement.modeAmortissement ?
                                                    this.ratificationInfo.planFinancement.modeAmortissement.code : null;
   this.criterGestRatifAvance.tva  = this.simulationFormGroup.get('arTauxTva').value;
  // this.criterGestRatifAvance.modeleRatification  =
   this.criterGestRatifAvance.vrApparante  = this.ratificationInfo.montantVrApparente ?
                                                this.ratificationInfo.montantVrApparente : null;
  // this.criterGestRatifAvance.modeSaisieVrApparante  =
   this.criterGestRatifAvance.clauseIndexation  = this.ratificationInfo.planFinancement.clauseIndexation ?
                                                    this.ratificationInfo.planFinancement.clauseIndexation : null;
   this.criterGestRatifAvance.commentairePalier  = this.ratificationInfo.commentairePalier ?
                                                      this.ratificationInfo.commentairePalier : null;
   // this.criterGestRatifAvance.afficheLoyerCoeff  =
   this.criterGestRatifAvance.vr  = this.ratificationInfo.planFinancement.montantVR ?
                                      this.ratificationInfo.planFinancement.montantVR : null;

  }
  buildSimulationForm() {
    this.simulationFormGroup = this._formBuilder.group({
      arReferenceApporteur: [this.ratificationInfo.referenceApporteur] ,
      arProduitCommercial: [this.listProduitsCom[this.produitComIndex],
      { updateOn: 'change',  asyncValidators: [() => this.validate()]}],
      arPeriodicite: [this.listPeriodicite[3],  { updateOn: 'change', asyncValidators: [() => this.validate()]}],
      arDuree: [this.ratificationInfo.planFinancement ? this.ratificationInfo.planFinancement.duree : null,
                { updateOn: 'change', validators: [Validators.required], asyncValidators: [() => this.validate()]}],
      arDerogation: [this.ratificationInfo.topDerogation],
      afOrigineDero: [this.ratificationInfo.topDerogation ? this.listOrigineDerog[this.motifDerInex] : null],
      arAuthRestante: [this.ratificationInfo.planFinancement ? this.ratificationInfo.planFinancement.montantFinancement : null],
      arMethodeCalcul: [this.methodeCalculList[1]],
      arTauxTva: [this.ratificationInfo.planFinancement ? this.ratificationInfo.planFinancement.tauxTVA : null,
            { updateOn: 'change', validators: [Validators.required], asyncValidators: [() => this.validate()]}],
      arLoyerFinancier: [this.ratificationInfo.planFinancement ? this.ratificationInfo.planFinancement.loyerFinancierMajore : null,
                        { updateOn: 'change', validators: [Validators.required], asyncValidators: [() => this.validate()]}],
      arMontant: [this.ratificationInfo.planFinancement ? this.ratificationInfo.planFinancement.montantFinancement : null,
        { updateOn: 'change', validators: [Validators.required],
       asyncValidators: [() => this.validate()]}],
      arTauxTEGM: [this.ratificationInfo.planFinancement ? this.ratificationInfo.planFinancement.taux : null,
        { updateOn: 'change', validators: [Validators.required], asyncValidators: [() => this.validate()]}],
      arFaisMontage: [this.ratificationInfo.montantFraisDeMontage ? this.ratificationInfo.montantFraisDeMontage.montant : null],
      arClauseIndexation: [this.ratificationInfo.planFinancement.clauseIndexation],
      arCommissionApporteur: [this.ratificationInfo.commissionApporteur],
      arBareme: [this.ratificationInfo.bareme],
      arBaremeElargi: [null],
      arBaremeOrigine: [null]
    });
    this.montantAuthrestante = this.formatNumber.transform(this.ratificationInfo.planFinancement.montantFinancement);
    this.commissionAppor = this.ratificationInfo.commissionApporteur;
    this.clauseIndexation = this.ratificationInfo.planFinancement.clauseIndexation ?
                                      this.ratificationInfo.planFinancement.clauseIndexation : '--';
    /* ajout des formControls en mode accord detaolle forcer */
    if ( this.modeForcer ) {
/*       this.simulationFormGroup.addControl('afOrigineDero',
                                            this._formBuilder.control(
                                              [null])); */
      this.simulationFormGroup.addControl('afListTaux',
                                            this._formBuilder.control(
                                              this.listTauxGlobal[0]));
      this.simulationFormGroup.addControl('afTauxGlobal',
                                            this._formBuilder.control(
                                              [null]));
      this.simulationFormGroup.addControl('afTauxRefin',
                                              this._formBuilder.control(
                                                [null]));
      this.simulationFormGroup.addControl('afTauxMarge',
                                            this._formBuilder.control(
                                              [null]));
      this.simulationFormGroup.addControl('afTypeTEGM',
                                            this._formBuilder.control(
                                              this.listTEGM[0]));
                                            /* { updateOn: 'change',
                                              asyncValidators: [() => this.validate()]}])); */
      this.simulationFormGroup.addControl('afModeAmortissement',
                                          this._formBuilder.control(
                                            [null]));
      this.simulationFormGroup.addControl('afTerme',
                                          this._formBuilder.control(
                                            [null]));
      this.simulationFormGroup.addControl('afAffichageLoyer',
                                          this._formBuilder.control(
                                            [null]));
    this.methodeCalculList.push(new ModelOption('Loyer financier et montant', 'TAU'));
    this.methodeCalculList.push(new ModelOption('Multi-paliers', 'MP'));
    }
     /* fin d'jout en mode forcer*/
  }
  buildPlanFinForm() {
    this.ComplPFFormGroup = this._formBuilder.group({
      arValResid: [this.ratificationInfo.planFinancement.montantVR],
      arTxVR: [this.typePercentMontant[0]],
      arPremierLM: [this.ratificationInfo.planFinancement.montantPremierLoyerMajore],
      arTxPLM: [this.typePercentMontant[0]]
  });
  }
  bluidCalageForm() {
     this.calageFormGroup = this._formBuilder.group({
      arCalage: [this.ratificationInfo.calage.topCalage],
      arNbrJours: [this.ratificationInfo.calage.nbJoursCalage]
  });
  this.isCalage = this.ratificationInfo.calage.topCalage;
  }
  buildObservation() {
    this.observationForm = this._formBuilder.group({
      adObservation: [null]
  });
  }
  buildReglement() {
    this.reglementFormGroup = this._formBuilder.group({
      modeReglement: [this.listModeReglement[this.modeRegIndex],
        { updateOn: 'change', asyncValidators: [() => this.validate()]}]
  });
  }
  buidIdentVendeur() {
    this.identVendeurFormGroup = this._formBuilder.group({
      adApporteur: [this.ratificationInfo.vendeur.agence.apporteur.libelle,
        { updateOn: 'change', asyncValidators: [() => this.validate()]}],
      adNom: [this.ratificationInfo.vendeur.nom],
      adPrenom: [this.ratificationInfo.vendeur.prenom],
      adAgence: [this.ratificationInfo.vendeur.agence.libelle],
      adMail: [this.ratificationInfo.vendeur.mail],
      adTelephone: [this.ratificationInfo.vendeur.telephone],
      adFax: [this.ratificationInfo.vendeur.fax]
  });
  }
  buidStatut() {
    this.statutFormGroup = this._formBuilder.group({
      adComStatut: [null],
      adComInterne: [null],
      adDateStatut: [null],
      adGestionStatut: [null]
  });
  }
  buildRachat() {
    this.rachatFormGroup = this._formBuilder.group({
      adMontantGI: [null],
      adAvantEchDe: [null]
  });
  }
  /* ------------------ autres majorations -----------*/
  addAutresMajForm(): void {
    if (this.listAutresMaj.length < 4) {
      this.addMajorFormToList();
    }
  }
  addMajorFormToList(): void {
    this.listAutresMaj = this.autresMajFormGroup.get('listAutresMaj') as FormArray;
    this.listAutresMaj.push(this.createAutresMajForm());
  }
  createAutresMajForm(): FormGroup {
    return this._formBuilder.group({
      typeAssurance: [null],
      montantAssurance: [null],
      typePercentAssurance: [this.tauxMajorationList[0]]
    });
  }
  /*   --------------------Assuarence à la personne -------------------   */
  buildAutresMaj() {
    this.autresMajFormGroup = this._formBuilder.group({
      listAutresMaj: this._formBuilder.array([]) });
      this.addMajorFormToList();
  }
  createAssuranceForm(): FormGroup {
    return this._formBuilder.group({
      typeAssurance: [null],
      montantAssurance: [this.defaultAssValue],
      typePercentAssurance: [this.typePercentMontant[0]]
    });
  }
  addAssuranceForm(): void {
    if ( this.listAssurances.length < 4) {
      this.addAssuranceFormToList();
    }
  }
  addAssuranceFormToList(): void {
    this.listAssurances = this.assuranceFormGroup.get('listAssurances') as FormArray;
    this.listAssurances.push(this.createAssuranceForm());
  }
  buildAssurance() {
    console.log('3.4 buildAssurance for PrestationAnnexesAssurances');
    this.assuranceFormGroup = this._formBuilder.group({
        listAssurances: this._formBuilder.array([]),
        listAssdommages: this._formBuilder.array([]),
        listAsspertefinancieres: this._formBuilder.array([]),
        assuranceMaintenance : this._formBuilder.group({
          typeAssurance: [null],
          montantAssurance: [null],
          typePercentAssurance: [null]
        })
    });
    this.addAssuranceFormToList();
    this.addAssdommageToList();
    this.addAsspertefinanciereToList();
  }
  buildAssMaintenance() {
    this.assMaintFormGroup = this._formBuilder.group({
      typeAssurance: [null],
      montantAssurance: [null],
      typePercentAssurance: [this.typePercentMontant[0]]
    });
  }
/*   --------------------Assuarence des Dommages -------------------   */
createAssurancedommageForm(): FormGroup {
  return this._formBuilder.group({
    typeAssurance: [null],
    montantAssurance: [null],
    typePercentAssurance: [this.typePercentMontant[0]]
/*     mntncesurEntrt: [null], */
  });
}
addAssdommage(): void {
  if ( this.listAssdommages.length < 4) {
    this.addAssdommageToList();
  }
}
addAssdommageToList(): void {
  this.listAssdommages = this.assuranceFormGroup.get('listAssdommages') as FormArray;
  this.listAssdommages.push(this.createAssurancedommageForm());
}
/*   --------------------Assuarence perte financiére  ------------------- */
createAssurancepertefinanciereForm(): FormGroup {
  return this._formBuilder.group({
    typeAssurance: [null],
    montantAssurance: [null],
    typePercentAssurance: [this.typePercentMontant[0]]
  });
}
addAsspertefinanciere(): void {
  if ( this.listAsspertefinancieres.length < 4) {
    this.addAsspertefinanciereToList();
  }
}
addAsspertefinanciereToList(): void {
  this.listAsspertefinancieres = this.assuranceFormGroup.get('listAsspertefinancieres') as FormArray;
  this.listAsspertefinancieres.push(this.createAssurancepertefinanciereForm());
}
buildMateriels() {
  console.log('3.2 buildMateriels');
  this.materielsFormGroup  = this._formBuilder.group({
    listMateriels: this._formBuilder.array([  ]),
  });
  this.addMaterielToList();
}
addMaterielToList(): void {
  this.listMateriels = this.materielsFormGroup.get('listMateriels') as FormArray;
  this.listMateriels.push(this.createMaterielForm());
}
buildGaranties() {
  this.garantiesFormGroup = this._formBuilder.group({
    listGaranties: this._formBuilder.array([])
    /* adSelGarantie : [null] */
  });
  this.listGaranties = this.garantiesFormGroup.get('listGaranties') as FormArray;
}
addGarantieToList(garantie: string): void {
  this.listGaranties = this.garantiesFormGroup.get('listGaranties') as FormArray;
   this.listGaranties.push(this.createGarantieForm(garantie));
}
createGarantieForm(garantie: string): FormGroup {
  return this._formBuilder.group({
    adTxtGarantie: [garantie]
  });
}
addGarantie(garantieSel: string): void {
  this.addGarantieToList(garantieSel);
}
createMaterielForm(): FormGroup {
  return this._formBuilder.group({
    mDesignation: [this.ratificationInfo.materielsFinancement[0].designation,
      { updateOn: 'change',  asyncValidators: [() => this.validate()]}],
    mFournisseur: [this.ratificationInfo.materielsFinancement[0].designation,
     { updateOn: 'change',  asyncValidators: [() => this.validate()]}],
    mType: [this.ratificationInfo.materielsFinancement[0].type,
     { updateOn: 'change',  asyncValidators: [() => this.validate()]}],
    mMarque: [null, { updateOn: 'change',  asyncValidators: [() => this.validate()]}],
    mQuantite: [null, { updateOn: 'change',  asyncValidators: [() => this.validate()]}],
    mNeuf: [null],
    mAnneeMiseService: [null],
    mNumeroSerie: [null, { updateOn: 'change',  asyncValidators: [() => this.validate()]}],
  });
}
addMateriel(): void {
      this.addMaterielToList();
  }
removeAssurnceForm(idx: number) {
  this.listGaranties.removeAt(idx);
}
initAllValue() {
  this.produitComIndex = this.getCodeProduitCommercial(this.ratificationInfo.planFinancement.produitFinancier.code);
 // this.periodiciteIndex = this.getCodePeriodicite(this.ratificationInfo.planFinancement.periodicite.code);
  this.modeRegIndex = this.getModeRegIndex(this.ratificationInfo.planFinancement.modeReglement.code);
  this.motifDerInex = this.ratificationInfo.topDerogation ? this.getMotifDerogIndex(this.ratificationInfo.motifDerogation.code) : 0;
}
buildAccordFromDossier() {
  this.buildAccordFromDossier$ = this.accordService
    .getDossierARatifier(this.numeroFL)
    .subscribe(
      data => {
        const result = data.content as RatificationInfo;
        this.ratificationInfo = result;
        this.getDossier();

        this.initAllValue();

        this.buildAccordDetaille();
        this.showSpinner = true;
        this.initDerogation();
      },
      err => {
        this.open(
          this.ts.instant('ACCORD_DETAILLE.MESSAGES_ERREURS.INIT_RATIF.ERROR')
        );
        console.log('erreur de récupération des infos', err);
        this.isRatifError = true;
        this.defineError(err);
      }
    );
  this.showSpinner = false;
}
buildAccordFromRatif() {
  console.log('buildAccordFromRatif');
  this.buildAccordFromRatif$ = this.ratifservice
  .getRatification({
    dossierId: this.numeroFL,
    contratId: this.chronoRatif
  })
  .subscribe(
    data => {
      const result = data.content as RatificationInfo;
      this.ratificationInfo = result;
      console.log('ratificationInfo' + JSON.stringify(this.ratificationInfo));
      this.getDossier();

      this.initAllValue();

      this.buildAccordDetaille();
      this.showSpinner = true;
      this.initDerogation();
    },
    err => {
      this.open(
        this.ts.instant('ACCORD_DETAILLE.MESSAGES_ERREURS.INIT_RATIF.ERROR')
      );
      console.log('erreur de récupération des infos', err);
      this.isRatifError = true;
      this.defineError(err);
    }
  );
  this.showSpinner = false;
}
defineError(err) {
  if (this.isRatifError) {
    this.authError$ = this.authService.setSubscribeError(err);
  }
}
open(msg) {
  this.openSnack('Error:', msg, 5000);
}
openSnack(type: string, msg: string, duree: number) {
  const mtConfig = new MatSnackBarConfig();
  mtConfig.panelClass = ['flashlease-class'];
  mtConfig.duration = duree;
  this.snackBar.open(type, msg, mtConfig);
}
replaceStatut(it) {
  if (!it) {
    return it;
  }
  return this.ts.instant(it);
}
initDossier(res) {
  this.ddfData = res as DossierInfo2;
  if (this.ddfData) {
    this.ddfData.statut.libelle = this.replaceStatut(
      this.ddfData.statut.libelle
    );
  }
  this.dossierHeader = DossierHeaderBuilder.setDossier(this.ddfData);
}
/** getInfo Dossier : param NumDossier */
getDossier() {
  this.ddf$ = this.ddfService.getDdf(this.numeroFL).subscribe(
    res => {
      this.dossier = res.content as DossierInfo;
      this.initDossier(res.content);
    },
    err => {
      console.log('erreur de récupération des infos', err);
      this.authError$ = this.authService.setSubscribeError(err);
    }
    );
}

initAccordFromDossier() {
   console.log('START CALL initAccordFromDossier...');
  this.apporteurDossierID = 8; //  --> valeur temporaire : this.ratificationInfo.vendeur.agence.apporteur.id;
  this.listProduit$ = this.accordService.
  getAllList(this.apporteurDossierID).subscribe(
    data => {
      const result = data.content as ListesForAccord;

    this.listProduitsCom = result.produitCommercial ? result.produitCommercial : null;
    this.listPeriodicite =  result.periodicite ?  result.periodicite : null;
    this.listBareme =  result.barameStandard ?  result.barameStandard : null;
    this.listBaremeElargi =  result.barameAvance ?  result.barameAvance : null;
    this.listModeReglement = result.modeRegelement ? result.modeRegelement : null;
    this.listAutresMajoration = result.autresMajoration ? result.autresMajoration : null;
    this.listModeAmort = result.modeAmmortCode ? result.modeAmmortCode : null;
    this.listTerme = result.termeCode ? result.termeCode : null;
    this.listGar = result.garanties ? result.garanties : null;
    this.listOrigineDerog = result.motifDerogation ? result.motifDerogation : null;
    this.getPrestations();

    if ( this.numeroFL) {
      if (!this.chronoRatif) {
        this.buildAccordFromDossier();
      } else {
        this.buildAccordFromRatif();
      }
    }
     // this.buildAccordFromDossier();
    } );
    console.log('END CALL initAccordFromDossier');
}

initAccordFromRatif() {
  console.log('START CALL initAccordFromRatif...');
  // TODO
  console.log('END CALL initAccordFromRatif');
}

getCodeProduitCommercial(codeProduitFinancier) {
  return this.listProduitsCom.findIndex(item => item.produitFinancier.code === codeProduitFinancier);
}
getModeRegIndex(codeReglement) {
  return this.listModeReglement.findIndex(item => item.code === codeReglement);
}
getMotifDerogIndex(codeMotif) {
  return this.listOrigineDerog.findIndex(item => item.code === codeMotif);
}

validate(c?: AbstractControl): Observable<ValidationErrors> {
  // check des autres erreurs comme required
  if (this.globalForm) {
    return this.validateAccord();
  }
  return new Observable();
}
validateAccord() {
  if (this.validator$) {
    const test = this.validator$.subscribe();
    test.unsubscribe();
  }
  this.validator$ = new Observable<ValidationErrors>(observer => {
   this.validatorHandler();
   observer.next();
   observer.complete();
 }).pipe(first(),
 debounceTime(this.waitingTime));
   return this.validator$;

}
validatorHandler(recall?: number) {
  this.lastCall =  new Date().getTime();
    if (this.lastCall < this.lastRecall + 750) {
      return null;
    }
    this.lastRecall = this.lastCall;
    const current = new Date().getTime();
    if (recall) {
      this.lastCall = current;
     this.isAbouttoValidate = false;
     console.log('validatorHandler');
      Global.unsubscriber(this.validate$);
      const data = {} as AccordDetaille;
      Object.keys(this.globalForm.controls).map(key => {
       if (this.globalForm && this.globalForm.controls[key] && this.globalForm.controls[key].touched) {
         data[key] = this.globalForm.controls[key].value;
       }
     });
      this.validate$ = this.accordService
       .AsyncValidatorAccord(data)
       .pipe()
       .subscribe(
         res => {
           console.log('Validation Successful');
           this.validationError = null;
           return null;
         },
         err => {
           console.log(err);
           let errorMessages = null;
           if (err && err.error) {
             errorMessages = JSON.parse(err.error.message);
           }
           this.validationError = errorMessages;
           return errorMessages;
         }
       );
 } else {
     setTimeout(() => {
       this.isAbouttoValidate = true;
       this.validatorHandler(current);
     }, this.waitingTime);
   }
}
isError(field: string) {
  return this.isValidateServerError(field);
}
isValidateServerError(field: string) {
  //  this.formSubmitted
  if (
    this.validationError && this.validationError[field]) {
      return true;
    }
    return false;
  }
  initDerogation() {
    console.log('initDerogation');
    if (this.simulationFormGroup.get('arDerogation').value) {
      console.log('coche');
      this.methodeCalculList.push(new ModelOption('Loyer financier et montant', 'TAU'));
      this.isModeDerogation = false;
    }
  }
checkClick() {
  this.isModeDerogation = !this.isModeDerogation;
  this.simulationFormGroup.get('arMethodeCalcul').reset();
  /* this.initMethodeCalcul(); */
  console.log('derogation : ' + this.simulationFormGroup.get('arDerogation').value);
  if (this.simulationFormGroup.get('arDerogation').value) {
    this.methodeCalculList.push(new ModelOption('Loyer financier et montant', 'TAU'));
  } else {
    this.methodeCalculList.pop();
  }
}
onChangeCalage() {
  this.calageFormGroup.get('arNbrJours').reset();
  this.calageFormGroup.get('arNbrJours').disable();
}
enbaleNbrJour () {
  this.calageFormGroup.get('arNbrJours').enable();
}
enableTauxMarge(taux: string) {
  console.log('taux : ' + taux);
  if (taux === 'TR') {
    this.showTauxMarge = !this.showTauxMarge;
    console.log('showTauxMarge : ' + this.showTauxMarge);
  }
}
initMethodeCalcul() {
  this.montantReadOnly = false;
  this.loyerFinReadOnly = false;
  this.tauxReadOnly = false;
  this.simulationFormGroup.get('arMontant').reset();
  this.simulationFormGroup.get('arLoyerFinancier').reset();
  this.simulationFormGroup.get('arTauxTEGM').reset();
}
onChangeMethode() {
  this.initMethodeCalcul();
  const selectedMethode = this.simulationFormGroup.get('arMethodeCalcul').value;
  switch (selectedMethode.libelle) {
    case this.MethodeEnum.LOYER_FINANCIER :
      {
        /*calcul du montant partie backend et le rendre en lecture seule*/
        this.simulationFormGroup.get('arMontant').setValue(99999);
        this.montantReadOnly = true;
        /*cacher le taux TEGM*/
        this.isModeDerogation = true;
      }
    break;
    case this.MethodeEnum.MONTANT :
    {
      /*calcul du loyer financier */
      this.simulationFormGroup.get('arLoyerFinancier').setValue(99999);
      this.loyerFinReadOnly = true;
      /*cacher le taux TEGM*/
      this.isModeDerogation = true;
    }
    break;
    case this.MethodeEnum.LOYER_MONTANT :
    {
      /* calcul du taux et le rendre en lecture seule */
      this.isModeDerogation = false;
      this.simulationFormGroup.get('arTauxTEGM').setValue(4);
      this.tauxReadOnly = true;
    }
    break;
    }
}
openRachatDetails() {
  const dialogRef = this.dialog.open(RachatDetailsComponent, {
    width: '1000px',
    data: { valeurRachat: this.valRachat, dateRachat: this.daterachat, numeroSIREN : this.ratificationInfo.client.siren }
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    if (result) {
      this.rachatFormGroup.get('adMontantGI').setValue(result.valeurRachat);
      this.rachatFormGroup.get('adAvantEchDe').setValue(Global.mapTimestampToDate(result.dateRachat.getTime()));
    }
  });
}
openMultiPaliers(methode) {
  console.log('selected Methode ' + methode.value);
  if ( methode.value === 'MP') {
    const dialogRef = this.dialog.open(MultiPaliersComponent, {
      width: '1270px',
      height: '900px',
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
}
getPrestations() {
     this.listPestations$ = this.contratService.
     getPrestations(this.montant).subscribe(
       data => {
          const list = data.content as FrfListPrestations;
          this.listPrestations = list;
       } );
 }
}
