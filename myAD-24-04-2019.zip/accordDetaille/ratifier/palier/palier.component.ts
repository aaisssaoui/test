import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';

@Component({
  selector: 'app-palier',
  templateUrl: './palier.component.html',
  styleUrls: ['./palier.component.scss']
})
export class PalierComponent implements OnInit {

  @Input()
  parentMultiPalForm: FormGroup;

  @Output()
  buttAdd = new EventEmitter<any>();

  listPeriodicite: any [] = [];

  constructor() { }

  ngOnInit() {
  }
  onClickAdd() {
    this.buttAdd.emit();
  }
  removePalierForm(idx: number) {
    (<FormArray>this.parentMultiPalForm.get('listPaliers')).removeAt(idx);
  }
}
