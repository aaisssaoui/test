import { TestBed, inject } from '@angular/core/testing';

import { AccordDetailleService } from './accord-detaille.service';

describe('AccordDetailleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AccordDetailleService]
    });
  });

  it('should be created', inject([AccordDetailleService], (service: AccordDetailleService) => {
    expect(service).toBeTruthy();
  }));
});
