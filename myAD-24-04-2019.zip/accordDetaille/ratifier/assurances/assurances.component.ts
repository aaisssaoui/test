import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormArray, FormGroup, FormGroupName } from '@angular/forms';
import { ContratService } from '../../../services/contrat/contrat.service';
import { KpiModel } from '../../../models/kpimodel';
import { ModelOption } from '../../../models/option-model';
import { FrfListPrestations, PrestationInfo } from '../../../models/ddf';

@Component({
  selector: 'app-assurances',
  templateUrl: './assurances.component.html',
  styleUrls: ['./assurances.component.scss']
})
export class AssurancesComponent implements OnInit {

  @Input()
  formGroupName: FormGroupName;

  @Input()
  parentBlocAssurForm: FormGroup;

/*   @Input()
  parentAssDommageForm: FormGroup; */

  @Input()
  listForm: FormArray;
  @Output()
  buttAdd = new EventEmitter<any>();
  @Output()
  btnAddAssDom = new EventEmitter<any>();
  @Output()
  btnAddAssFin = new EventEmitter<any>();

  @Input()
  listAssurPerso: ModelOption[];

  @Input()
  listAssurDom: ModelOption[];

  @Input()
  listAssurPertFin: ModelOption[];

  @Input()
  valeurParDefaut;
  public prestation: ModelOption;
  @Input()
  ref;
  removable = false;
  removableAssDom = false;
  removableAssFin = false;
  label;

  typePourcentageMontant: ModelOption[] = [
    new ModelOption('% du montant', 'montantP'),
    new ModelOption('% du loyer', 'loyerP'),
    new ModelOption('€', 'euro'),
    new ModelOption('Montant total des prestations', 'montantT'),
  ];

  @Input()
  listPercentPrestation;

  @Input()
  toto;

  constructor() { this.toto = 20; }

  ngOnInit() {
    /* this.getPrestations(); */
  }

  removeAssurnceForm(idx: number) {
    (<FormArray>this.parentBlocAssurForm.get('listAssurances')).removeAt(idx);
  }

  removeAssurncedommageForm(idx: number) {
    (<FormArray>this.parentBlocAssurForm.get('listAssdommages')).removeAt(idx);
  }
  removeAssurncepertefiForm(idx: number) {
    (<FormArray>this.parentBlocAssurForm.get('listAsspertefinancieres')).removeAt(idx);

  }

   onClickAdd() {
    this.buttAdd.emit();
  }
  onClickAddAssDom() {
    this.btnAddAssDom.emit();
  }
  onClickAddAssFin() {
    this.btnAddAssFin.emit();
  }

}
