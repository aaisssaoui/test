import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatifierComponent } from './ratifier.component';

describe('RatifierComponent', () => {
  let component: RatifierComponent;
  let fixture: ComponentFixture<RatifierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatifierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatifierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
