import { Component, OnInit, Inject } from '@angular/core';
import { TableColumnDefinitionModel } from '../../../models/table-column-definition-model';
import { TranslateService } from '@ngx-translate/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBarConfig, MatSnackBar } from '@angular/material';
import * as _ from 'lodash';
import { CritereRechercheInfo } from '../../../models/critere-recherche-info';
import { CriteresRechercheRachatVo, Rachat, RachatVo } from '../../../models/ddf';
import { RachatService } from '../../../services/rachat/rachat.service';
/* test pour la maquette */
export class RachatDetail {
  checked: boolean;
  reference: string;
  siren: number;
  raisonSocial: string;
  numAffaire: string;
  referenceExterne: string;
  dateRachat: Date;
  dateValidite: Date;
  valeurRachat: number;

  constructor(reference,
              siren,
              raisonSocial,
              numAffaire,
              referenceExterne,
              dateRachat,
              dateValidite,
              valeurRachat  ) {
    this.checked = false;
    this.reference = reference;
    this.siren = siren;
    this.raisonSocial = raisonSocial;
    this.numAffaire = numAffaire;
    this.referenceExterne = referenceExterne;
    this.dateRachat = dateRachat;
    this.dateValidite = dateValidite;
    this.valeurRachat = valeurRachat;
  }
}
/*fin test*/
@Component({
  selector: 'app-rachat-details',
  templateUrl: './rachat-details.component.html',
  styleUrls: ['./rachat-details.component.scss']
})
export class RachatDetailsComponent implements OnInit {

  isPaginationNeeded = false;
  rachatDataSource: RachatDetail[] = [];
/*     [{
      checked: false, reference: '001020', siren: 5521202222, raisonSocial: 'TEST',
      numAffaire: '147751632', referenceExterne: 'REFTEST', dateRachat: new Date('2019-01-03'),
      dateValidite: new Date('2019-01-24'), valeurRachat: 3000.00
    },
    {
      checked: false, reference: '001021', siren: 5521202222, raisonSocial: 'TEST',
      numAffaire: '147751632', referenceExterne: 'REFTEST', dateRachat: new Date('2019-03-15'),
      dateValidite: new Date('2019-03-16'), valeurRachat: 4000.00
    },
    {
      checked: false, reference: '001022', siren: 5521202222, raisonSocial: 'TEST',
      numAffaire: '147751632', referenceExterne: 'REFTEST', dateRachat: new Date('2019-01-22'),
      dateValidite: new Date('2019-01-28'), valeurRachat: 2000.00
    },
    {
      checked: false, reference: '001023', siren: 5521202222, raisonSocial: 'TEST',
      numAffaire: '147751632', referenceExterne: 'REFTEST', dateRachat: new Date('2019-02-09'),
      dateValidite: new Date('2019-02-10'), valeurRachat: 1000.00
    }
  ]; */
  errorMsgType: string;
  errorMsgSize: string;
  columnsRachat: TableColumnDefinitionModel[];

  valRachat: number;
  daterachat: Date;

  public showSpinner = false;

  selectedRachat: RachatDetail[] = [];
  public rachats$;
  siren : number;

  constructor(public transServ: TranslateService,
              public dialogRef: MatDialogRef<RachatDetailsComponent>,
              @Inject(MAT_DIALOG_DATA) public data: DialogRachatData,
              private rachatService: RachatService,
              private ts: TranslateService,
              private snackBar: MatSnackBar) {
    this.transServ.get('DDF.FORM.ERROR.file_error_type').subscribe(it => {
      this.columnsRachat = this.buildColumnsRachat();
      this.errorMsgType = it;
      this.errorMsgSize = this.transServ.instant(
        'DDF.FORM.ERROR.file_error_size'
      );
    });
    this.siren = data.numeroSIREN;
  }
  getRachats(numeroSIREN) {
    const criteres: CriteresRechercheRachatVo = {};
    criteres.sirenClient = numeroSIREN;
    this.rachats$ = this.rachatService.search(criteres)
    .subscribe(
      data => {
          const result = data.content.rachats as RachatVo[];
          console.log('result : ' + JSON.stringify(result));
          result.map(
          item =>
                item.offresRachat.map(ele => this.rachatDataSource.push(new RachatDetail(item.referenceRachat ? item.referenceRachat : null,
                  item.sirenClient ? item.sirenClient : null,
                  item.raisonSocialeClient ? item.raisonSocialeClient : null,
                  item.infoAffaire.numeroAffaire ? item.infoAffaire.numeroAffaire : null,
                  item.infoAffaire.referenceExterne ? item.infoAffaire.referenceExterne : null,
                  item.dateRachat ? item.dateRachat : item.dateRachat,
                  ele.dateValidite,
                  ele.montantTTC
                  ) ))
           );
        this.showSpinner = true;
        console.log('rachatDataSource' + this.rachatDataSource);
      },
      err => {
        this.open(
          this.ts.instant('ACCORD_DETAILLE.MESSAGES_ERREURS.INIT_RATIF.ERROR')
        );
        console.log('erreur de récupération des rachats', err);
      }
    );
    this.showSpinner = false;
  }
  open(msg) {
    this.openSnack('Error:', msg, 5000);
  }
  openSnack(type: string, msg: string, duree: number) {
    const mtConfig = new MatSnackBarConfig();
    mtConfig.panelClass = ['flashlease-class'];
    mtConfig.duration = duree;
    this.snackBar.open(type, msg, mtConfig);
  }
  getRachatInfo(rachat: RachatDetail) {
    rachat.checked = !rachat.checked;
    if (rachat.checked) {
      this.selectedRachat.push(rachat);
    }
    if (!rachat.checked) {
      console.log(this.selectedRachat.indexOf(rachat));
      this.selectedRachat.splice(this.selectedRachat.indexOf(rachat), 1);
    }
    console.log(this.selectedRachat);
  }
  buildColumnsRachat() {
    return [
      {
        header: '',
        checkbox: (row: RachatDetail) => (this.getRachatInfo(row)),
        columnDef: 'checked',
        cell: (row: RachatDetail) => ''
      },
      {
        columnDef: 'reference',
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.REFERENCE'),
        cell: (row: RachatDetail) => row.reference
      },
      {
        columnDef: 'siren',
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.SIREN'),
        cell: (row: RachatDetail) => row.siren
      },
      {
        columnDef: 'raisonSocial',
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.RAISON_SOCIALE'),
        cell: (row: RachatDetail) => row.raisonSocial
      },
      {
        columnDef: 'numAffaire',
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.NUMERO_AFFAIRE'),
        cell: (row: RachatDetail) => row.numAffaire
      },
      {
        columnDef: 'referenceExterne',
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.REFERENCE_EXTERNE'),
        cell: (row: RachatDetail) => row.referenceExterne
      },
      {
        columnDef: 'dateRachat',
        date: true,
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.DATE_RACHAT'),
        cell: (row: RachatDetail) => row.dateRachat
      },
      {
        columnDef: 'dateValidite',
        date: true,
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.DATE_VALIDITE'),
        cell: (row: RachatDetail) => row.dateValidite
      },
      {
        columnDef: 'valeurRachat',
        header: this.transServ.instant('ACCORD_DETAILLE.STATUS_RATIFICATION.TABLE.VALEUR_RACHAT'),
        cell: (row: RachatDetail) => row.valeurRachat
      }
    ] as TableColumnDefinitionModel[];
  }
  ngOnInit() {
    console.log('siren : ' + this.siren);
    this.getRachats(this.siren);
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  onValidate() {
    this.data.valeurRachat = _.sumBy(this.selectedRachat, 'valeurRachat');
    /* console.log(this.valRachat); */
    /* console.log('this.data.valeurAchat : ' + this.data.valeurAchat); */

    this.data.dateRachat = _.orderBy(this.selectedRachat, ['dateRachat'], ['desc'])[0].dateRachat;
    /* console.log('this.daterachat : ' + this.data.dateRachat); */
  }
}
export interface DialogRachatData {
  valeurRachat: number;
  dateRachat: Date;
  numeroSIREN: number;
}
