import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ModelOption } from '../../../models/option-model';
import { FormArray, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-multi-paliers',
  templateUrl: './multi-paliers.component.html',
  styleUrls: ['./multi-paliers.component.scss']
})
export class MultiPaliersComponent implements OnInit {

  listTauxGlobal: ModelOption[] = [
    new ModelOption('Taux global', 'TG'),
    new ModelOption('Taux de refinancement', 'TR')
  ];

  listTEGM: ModelOption[] = [
    new ModelOption('TEGM', 'TEGM'),
    new ModelOption('TEGT', 'TEGT'),
    new ModelOption('TEGS', 'TEGS'),
    new ModelOption('TEGA', 'TEGA')
  ];
  methodeCalculMP: ModelOption[] = [
    new ModelOption('Encours fonction des loyers saisis', 'EL'),
    new ModelOption('Loyer fonction des encours saisis', 'LE')
  ];
  MultiPaliersForm: FormGroup;
  listPaliers: FormArray;
  paliersFormGroup: FormGroup;

  constructor(@Inject(MAT_DIALOG_DATA) public data: DialogMPData,
              public dialogRef: MatDialogRef<MultiPaliersComponent>,
              private _formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.buildListpaliers();
    this.buildMuliPaliesForm();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onValidate() {
    console.log('On Validate !!');
  }
  buildMuliPaliesForm() {
    this.MultiPaliersForm = this._formBuilder.group({
      mpMontant: [null],
      mpTypeTaux: [null],
      mpTaux : [null],
      mpTypeTEGM : [null],
      mpMethodeCalcul : [null],
      listPaliersForm: this.listPaliers
    });
  }
  addPalierForm(): void {
      this.addPalierFormToList();
  }
  addPalierFormToList(): void {
    this.listPaliers = this.paliersFormGroup.get('listPaliers') as FormArray;
    this.listPaliers.push(this.createPaliersForm());
  }
  createPaliersForm(): FormGroup {
    return this._formBuilder.group({
      mpRang: [null],
      mpNbrEch: [null]
    });
  }
  buildListpaliers() {
    this.paliersFormGroup = this._formBuilder.group({
      listPaliers: this._formBuilder.array([]) });
      this.addPalierForm();
  }

}
export interface DialogMPData {
  montantFinancier: number;
  tauxGlobal: number;
  nbrEcheance: number;
}
