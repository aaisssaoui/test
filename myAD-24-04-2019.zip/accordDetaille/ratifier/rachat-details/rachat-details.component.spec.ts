import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RachatDetailsComponent } from './rachat-details.component';

describe('RachatDetailsComponent', () => {
  let component: RachatDetailsComponent;
  let fixture: ComponentFixture<RachatDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RachatDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RachatDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
